function retval = logsig (val)
  retval = 1./(exp(-1.*val)+1);
endfunction