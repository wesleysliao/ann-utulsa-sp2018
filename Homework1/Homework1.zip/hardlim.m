function retval = hardlim (val)
  retval = (val > 0);
endfunction